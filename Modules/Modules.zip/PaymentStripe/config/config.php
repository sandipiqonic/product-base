<?php

return [
    'name' => 'PaymentStripe',
];
