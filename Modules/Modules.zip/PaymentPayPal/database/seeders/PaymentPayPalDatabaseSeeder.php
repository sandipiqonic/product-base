<?php

namespace Modules\PaymentPayPal\Database\Seeders;

use Illuminate\Database\Seeder;

class PaymentPayPalDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
