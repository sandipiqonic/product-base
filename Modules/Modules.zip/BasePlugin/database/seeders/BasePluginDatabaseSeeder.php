<?php

namespace Modules\BasePlugin\Database\Seeders;

use Illuminate\Database\Seeder;

class BasePluginDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
