<?php

use Illuminate\Support\Facades\Route;
use Modules\BasePlugin\App\Http\Controllers\BasePluginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::group([], function () {
//     Route::resource('baseplugin', BasePluginController::class)->names('baseplugin');
// });
Route::middleware(['web'])->prefix('baseplugin')->group(function () {
    Route::get('/', [BasePluginController::class, 'index'])->name('baseplugin.index');
    Route::post('/upload', [BasePluginController::class, 'upload'])->name('baseplugin.upload');
    Route::post('/activate', [BasePluginController::class, 'activate'])->name('baseplugin.activate');
    Route::post('/deactivate', [BasePluginController::class, 'deactivate'])->name('baseplugin.deactivate');
});