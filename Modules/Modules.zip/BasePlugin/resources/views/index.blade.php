@extends('baseplugin::layouts.master')

@section('content')
    <div class="container">
        <h1>Plugin Management</h1>

        <form action="{{ route('baseplugin.upload') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="plugin">Upload Plugin (ZIP file)</label>
                <input type="file" class="form-control" id="plugin" name="plugin" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload and Install</button>
        </form>

        <h2>Installed Plugins</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Alias</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($plugins as $plugin)
                <tr>
                    <td>{{ $plugin->name }}</td>
                    <td>{{ $plugin->alias }}</td>
                    <td>{{ ucfirst($plugin->status) }}</td>
                    <td>
                        @if ($plugin->status == 'activated')
                        <form action="{{ route('baseplugin.deactivate') }}" method="POST" style="display: inline;">
                            @csrf
                            <input type="hidden" name="alias" value="{{ $plugin->alias }}">
                            <button type="submit" class="btn btn-warning">Deactivate</button>
                        </form>
                        @else
                        <form action="{{ route('baseplugin.activate') }}" method="POST" style="display: inline;">
                            @csrf
                            <input type="hidden" name="alias" value="{{ $plugin->alias }}"> 
                            <button type="submit" class="btn btn-success">Activate</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
