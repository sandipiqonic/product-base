<?php

namespace Modules\BasePlugin\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Artisan;
use Modules\BasePlugin\Entities\Plugin;
use ZipArchive;

class PluginController extends Controller
{
    public function index()
    {
        $plugins = Plugin::all();
        return view('baseplugin::index', compact('plugins'));
    }

    public function upload(Request $request)
    {
        $request->validate([
            'plugin' => 'required|file|mimes:zip',
        ]);

        $file = $request->file('plugin');
        $fileName = time() . '_' . $file->getClientOriginalName();
        $destinationPath = storage_path('app/plugins');

        if (!File::exists($destinationPath)) {
            File::makeDirectory($destinationPath, 0755, true);
        }

        $file->move($destinationPath, $fileName);

        $zip = new ZipArchive;
        if ($zip->open($destinationPath . '/' . $fileName) === TRUE) {
            $zip->extractTo(base_path('Modules'));
            $zip->close();

            // Assuming module's main directory name is same as zip's main directory
            $moduleDir = trim($zip->getNameIndex(0), '/');

            // Run migrations for the new module
            Artisan::call('module:migrate', ['module' => $moduleDir]);

            // Register the module in the plugins table
            Plugin::create([
                'name' => $moduleDir,
                'alias' => strtolower($moduleDir),
                'status' => 'installed'
            ]);

            return redirect()->back()->with('success', 'Plugin uploaded and installed successfully.');
        } else {
            return redirect()->back()->with('error', 'Failed to extract the plugin.');
        }
    }

    public function activate($alias)
    {
        $plugin = Plugin::where('alias', $alias)->firstOrFail();
        $plugin->update(['status' => 'activated']);

        // Additional logic to enable the plugin can be added here

        return redirect()->back()->with('success', 'Plugin activated successfully.');
    }

    public function deactivate($alias)
    {
        $plugin = Plugin::where('alias', $alias)->firstOrFail();
        $plugin->update(['status' => 'deactivated']);

        // Additional logic to disable the plugin can be added here

        return redirect()->back()->with('success', 'Plugin deactivated successfully.');
    }
}
