<?php

namespace Modules\BasePlugin\App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Artisan;
use Modules\BasePlugin\Entities\Plugin;
use ZipArchive;

class BasePluginController extends Controller
{
    public function index()
    {
        $plugins = Plugin::all();
        return view('baseplugin::index', compact('plugins'));
    }

    public function upload(Request $request)
    {
        $request->validate([
            'plugin' => 'required|file|mimes:zip',
        ]);

        $file = $request->file('plugin');
        $fileName = time() . '_' . $file->getClientOriginalName();
        $destinationPath = storage_path('app/plugins');

        if (!File::exists($destinationPath)) {
            File::makeDirectory($destinationPath, 0755, true);
        }
        $filePath = $destinationPath . '/' . $fileName;
        $file->move($destinationPath, $fileName);

        $zip = new ZipArchive;

        if ($zip->open($filePath) === TRUE) {

            // Assuming module's main directory name is the first directory in the zip
            $moduleDir = null;
            $dirName = "";
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $name = $zip->getNameIndex($i);
                $noSlash = substr($name, -1);
                if ($noSlash === '/') {
                    $moduleDir = trim($name, '/');
                    $dirName = explode("/", $moduleDir)[0];
                    break;
                }
            }
            if (!$moduleDir) {
                $zip->close();
                return redirect()->back()->with('error', 'Invalid plugin structure.');
            }

            $zip->extractTo(base_path('Modules'));
            $zip->close();

            // Convert the module directory to a proper module name
            $moduleName = ucfirst(str_replace('_', ' ', $moduleDir));
            // Run migrations for the new module
            $moduleName = $moduleDir;


            $configPath = base_path('Modules/'.$dirName) . '/module.json';

            if (!File::exists($configPath)) {
                dd("AA",$configPath);
                return "`Modules.json` file missing!";
            }
            // Read and decode the JSON configuration file
            $moduleConfig = json_decode(File::get($configPath), true);
            $version = (isset($moduleConfig['version'])) ? $moduleConfig['version'] : false;
            if(!$version){
                return redirect()->back()->with('error', 'Invalid module configuration. Version is missing.');
            }

            $pluginExist = Plugin::where('alias', $dirName)->first();

            // TODO: check if plugin already exist or not
            // If exist, Delete uploaded zip, extracted folder and db entry RETURN.

            // Register the module in the plugins table
            Plugin::updateOrCreate([
                'name' => $dirName,
                'alias' => strtolower($dirName),
                'version' => $version
                // 'status' => 'installed'
            ]);

            return redirect()->back()->with('success', 'Plugin uploaded and installed successfully.');
        } else {
            return redirect()->back()->with('error', 'Failed to open the plugin zip file.');
        }
    }

    public function activate(Request $request)
    {
        $plugin = Plugin::where('alias', $request->input('alias'))->firstOrFail();
        $plugin->update(['status' => 'activated']);

        // Additional logic to enable the plugin can be added here

        return redirect()->back()->with('success', 'Plugin activated successfully.');
    }

    public function deactivate(Request $request)
    {
        $plugin = Plugin::where('alias', $request->input('alias'))->firstOrFail();
        $plugin->update(['status' => 'deactivated']);

        // Additional logic to disable the plugin can be added here

        return redirect()->back()->with('success', 'Plugin deactivated successfully.');
    }
}
