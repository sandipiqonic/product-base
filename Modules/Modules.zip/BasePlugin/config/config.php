<?php

return [
    'name' => 'BasePlugin',
];
