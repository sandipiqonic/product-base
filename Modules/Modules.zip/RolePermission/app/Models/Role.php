<?php

namespace Modules\RolePermission\Entities;

use Spatie\Permission\Models\Role as SpatieRole;

class Role extends SpatieRole
{
    // Custom code or overrides if needed
}

