<?php

namespace Modules\RolePermission\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Modules\RolePermission\app\Models\Permission;

class RolePermissionDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
        // Check if the route entry already exists before inserting it
        $existingRoute = DB::table('routes')->where([
            'name' => 'roles.index',
            'method' => 'GET',
            'uri' => '/',
            'controller' => 'RoleController@index',
            'middleware' => 'web',
        ])->first();

        if (!$existingRoute) {
            // If the route entry doesn't exist, insert it
            DB::table('routes')->insert([
                'name' => 'roles.index',
                'method' => 'GET',
                'uri' => '/',
                'controller' => 'RoleController@index',
                'middleware' => 'web',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        // Insert permissions only if they don't already exist
        $permissions = [
            [
                'id' => 1,
                'name' => 'role',
                'title' => 'Role',
                'guard_name' => 'web',
                'parent_id' => NULL,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'name' => 'role add',
                'title' => 'Role Add',
                'guard_name' => 'web',
                'parent_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 3,
                'name' => 'role list',
                'title' => 'Role List',
                'guard_name' => 'web',
                'parent_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 4,
                'name' => 'permission',
                'title' => 'Permission',
                'guard_name' => 'web',
                'parent_id' => NULL,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 5,
                'name' => 'permission add',
                'title' => 'Permission Add',
                'guard_name' => 'web',
                'parent_id' => 4,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 6,
                'name' => 'permission list',
                'title' => 'Permission List',
                'guard_name' => 'web',
                'parent_id' => 4,
                'created_at' => '2021-06-04 06:59:54',
                'updated_at' => '2021-06-04 06:59:54',
            ],
        ];

        foreach ($permissions as $permissionData) {
            $permission =  Permission::find($permissionData['id']);
            if (!$permission) {
                Permission::create($permissionData);
            }
        }
    }
}
