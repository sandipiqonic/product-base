@extends('rolepermission::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('rolepermission.name') !!}</p>
@endsection
