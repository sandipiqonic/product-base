<?php

return [
    'name' => 'PaymentPayPal',
];
