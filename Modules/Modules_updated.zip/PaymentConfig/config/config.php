<?php

return [
    'name' => 'PaymentConfig',
];
