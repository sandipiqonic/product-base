<?php

return [
    'name' => 'RolePermission',
];
