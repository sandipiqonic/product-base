<?php

namespace Modules\PaymentStripe\Database\Seeders;

use Illuminate\Database\Seeder;

class PaymentStripeDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
