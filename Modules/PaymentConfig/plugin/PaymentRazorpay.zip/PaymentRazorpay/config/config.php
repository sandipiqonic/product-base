<?php

return [
    'name' => 'PaymentRazorpay',
];
